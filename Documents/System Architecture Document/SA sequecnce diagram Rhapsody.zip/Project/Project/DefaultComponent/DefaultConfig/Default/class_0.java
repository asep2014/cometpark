/*********************************************************************
	Rhapsody	: 8.0.3
	Login		: hxn121330
	Component	: DefaultComponent
	Configuration 	: DefaultConfig
	Model Element	: class_0
//!	Generated Date	: Wed, 5, Mar 2014 
	File Path	: DefaultComponent/DefaultConfig/Default/class_0.java
*********************************************************************/

package Default;


//----------------------------------------------------------------------------
// Default/class_0.java                                                                  
//----------------------------------------------------------------------------

//## package Default 


//## class class_0 
public class class_0 {
    
}
/*********************************************************************
	File Path	: DefaultComponent/DefaultConfig/Default/class_0.java
*********************************************************************/

